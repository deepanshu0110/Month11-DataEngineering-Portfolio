# Month 11 — Data Engineering Portfolio

LogiTrack India — an end-to-end data engineering capstone: ETL pipeline with an automated test gate, partitioned cloud storage, scheduled CI/CD, and a process-mining conformance monitor.

![Architecture diagram](docs/architecture_diagram.png)

## Results (verified run — seed=181 / seed=190)

| Metric | Value |
|---|---|
| Raw rows | 538 |
| Clean rows (after dedup) | 530 |
| High-delay shipments (>14 days transit) | 234 (44.15%) |
| Revenue at risk | Rs 3,05,612.65 |
| Data-quality gate | 6/6 checks passed |
| Process conformance | 71.32% (378/530) — below 80% alert threshold |
| Worst carrier by transit time | Delhivery (13.13 days) |
| Worst carrier by conformance | BlueDart (61.70%) |

See [`docs/NRA_Capstone_Business_Case.md`](docs/NRA_Capstone_Business_Case.md) for the full analysis — including why the carrier-level differences above are explained by a delay-linked mechanism, not a carrier-specific defect.

## Day Index (auto-generated — do not edit by hand)

<!-- DAY_INDEX_START -->
| Day | Topic | File |
|---|---|---|
| 181 | ETL Extract Transform | `notebooks/Day181_ETL_Extract_Transform.ipynb` |
| 182 | ETL Scheduling ErrorHandling | `notebooks/Day182_ETL_Scheduling_ErrorHandling.ipynb` |
| 183 | GitHubActions CICD Part1 | `notebooks/Day183_GitHubActions_CICD_Part1.ipynb` |
| 184 | GitHubActions CICD Part2 | `notebooks/Day184_GitHubActions_CICD_Part2.ipynb` |
| 185 | AWS S3 Part1 | `notebooks/Day185_AWS_S3_Part1.ipynb` |
| 186 | AWS S3 Part2 PartitionedETL | `notebooks/Day186_AWS_S3_Part2_PartitionedETL.ipynb` |
| 187 | ProcessMining pm4py Part1 | `notebooks/Day187_ProcessMining_pm4py_Part1.ipynb` |
| 188 | ProcessMining pm4py Part2 Conformance | `notebooks/Day188_ProcessMining_pm4py_Part2_Conformance.ipynb` |
| 189 | Capstone Part1 Unified Pipeline | `notebooks/Day189_Capstone_Part1_Unified_Pipeline.ipynb` |
| 190 | Capstone Part2 Monitoring | `notebooks/Day190_Capstone_Part2_Monitoring.ipynb` |
| 191 | Capstone Final Report | `notebooks/Day191_Capstone_Final_Report.ipynb` |
<!-- DAY_INDEX_END -->

> **Note:** Days 181-188 notebooks are placeholders in this table — drop your actual files from those sessions into `notebooks/` using the exact filenames above, and `auto_sync_month11.py` will pick them up and keep this table accurate on every save.

## Tech stack

Python, pandas, numpy, boto3 + moto (S3 mocking), graphviz, GitHub Actions, pm4py (Days 187-188)

## How to run

```bash
pip install -r requirements.txt
python src/pipeline.py       # runs ETL + test gate + S3 load + process-mining monitor
python src/test_gate.py      # standalone CI gate, exits 1 on failure
```

## Repository structure

```
.
├── README.md
├── requirements.txt
├── auto_sync_month11.py
├── notebooks/              # one .ipynb per day, Raw Data -> Practice -> Concept Notes -> Answer Key -> Rubric
├── src/
│   ├── pipeline.py         # LogiTrackPipeline class
│   └── test_gate.py        # standalone CI gate
├── capstone_raw/
│   └── run_summary.json    # latest run's metrics + gate result
├── .github/workflows/
│   └── logitrack_monitor.yml
├── docs/
│   ├── architecture_diagram.png
│   └── NRA_Capstone_Business_Case.md
└── scorecard_month11.md
```

---
*Part of a 12-month self-directed Data Science & AI curriculum — Month 11: Data Engineering.*
